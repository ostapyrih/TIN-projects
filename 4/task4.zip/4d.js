function sortLetters(str) {
  return str.split('').sort().join('');
}

console.log(sortLetters("webmaster"));