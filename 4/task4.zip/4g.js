function getType(arg) {
  return typeof(arg);
}

console.log(getType(1));